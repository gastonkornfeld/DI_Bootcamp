const db = require('../connections/connect-heroku-db.js');

const _getAllProduct = () => {
  return db('products')
  .select('id','name','price')
  .orderBy('name');
}

module.exports = {
  _getAllProduct
}
